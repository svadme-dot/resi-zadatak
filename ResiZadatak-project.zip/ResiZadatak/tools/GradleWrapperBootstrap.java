import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal bootstrap used only because the generation sandbox could not download
 * Gradle's standard wrapper JAR. On a normal machine Android Studio may replace
 * this with the standard wrapper at any time.
 */
public final class GradleWrapperBootstrap {
    public static void main(String[] args) throws Exception {
        Path project = Paths.get("").toAbsolutePath();
        Path propsFile = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(propsFile)) {
            props.load(in);
        }

        String distributionUrl = props.getProperty("distributionUrl").replace("\\:", ":");
        String zipName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String gradleDirName = zipName.replace("-bin.zip", "").replace("-all.zip", "");
        Path distRoot = Paths.get(System.getProperty("user.home"), ".gradle", "wrapper", "dists", "resi-zadatak", gradleDirName);
        Path gradleHome = distRoot.resolve(gradleDirName);

        if (!Files.exists(gradleHome.resolve("bin/gradle")) && !Files.exists(gradleHome.resolve("bin/gradle.bat"))) {
            Files.createDirectories(distRoot);
            Path zip = distRoot.resolve(zipName);
            if (!Files.exists(zip)) download(distributionUrl, zip);
            unzip(zip, distRoot);
        }

        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        Path executable = gradleHome.resolve(windows ? "bin/gradle.bat" : "bin/gradle");
        if (!windows) executable.toFile().setExecutable(true);

        List<String> command = new ArrayList<>();
        command.add(executable.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command).directory(project.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static void download(String url, Path destination) throws Exception {
        System.out.println("Downloading " + url);
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setInstanceFollowRedirects(true);
        connection.setConnectTimeout(15_000);
        connection.setReadTimeout(60_000);
        connection.setRequestProperty("User-Agent", "ResiZadatak-GradleBootstrap/1.0");
        int code = connection.getResponseCode();
        if (code < 200 || code >= 400) throw new IllegalStateException("Gradle download failed: HTTP " + code);
        try (InputStream in = connection.getInputStream()) {
            Files.copy(in, destination, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void unzip(Path zip, Path destination) throws Exception {
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null) {
                Path output = destination.resolve(entry.getName()).normalize();
                if (!output.startsWith(destination)) throw new IllegalStateException("Unsafe ZIP entry: " + entry.getName());
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    Files.copy(in, output, StandardCopyOption.REPLACE_EXISTING);
                }
                in.closeEntry();
            }
        }
    }
}
