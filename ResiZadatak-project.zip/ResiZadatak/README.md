# Reši zadatak

Native Android application for solving school exercises from a photograph with the Gemini API. The interface is deliberately simple and all user-facing text is Serbian Latin.

## Main flow

1. Open the app.
2. Tap **Dodaj novi zadatak**.
3. Choose **Izaberi iz galerije** or **Slikaj zadatak**.
4. Select/capture exactly one image.
5. Review the image and optionally type exactly which exercise/subtask should be solved.
6. Tap **Pošalji**.
7. Continue asking follow-up questions in the same persistent conversation.

Selecting a photo never submits it automatically. If one photo contains many exercises, the system instruction tells the model to solve only the exercise/subtask explicitly requested; if the user did not specify one, the model should ask which one to solve.

## Tech stack

- Kotlin 2.4.10
- Jetpack Compose + Material 3
- Android Gradle Plugin 9.3.0
- compileSdk / targetSdk 37, minSdk 26
- Room 2.8.4
- Kotlin Coroutines + StateFlow
- Android Photo Picker (`PickVisualMedia`), single image only
- Camera capture with `TakePicture` + `FileProvider`
- Google Gen AI Java SDK `com.google.genai:google-genai:1.63.0`
- Gemini model configured in one place: `gemini-3.7-flash`

## Gemini configuration

The prototype is configured in `GeminiAiService.kt` with:

- model: `gemini-3.7-flash`
- image + text input
- system instruction in Serbian Latin
- thinking level: `high`
- thought output disabled (`includeThoughts(false)`)
- Code Execution enabled as the only model tool
- no automatic Google Search grounding
- non-streaming generation for the first version, prioritizing reliability

The model ID is centralized in `GeminiConfig.MODEL_ID` so it can be changed without touching UI/database code.

The Google Gen AI SDK is isolated behind `AiService`. This makes it possible to replace direct client access later with a secure backend/proxy without rewriting the Compose screens or Room persistence layer.

## API key and local.properties

Do **not** put a real API key in committed Kotlin source.

Copy:

```text
local.properties.example
```

to:

```text
local.properties
```

and set your Android SDK path and key, for example on Windows:

```properties
sdk.dir=C\:\\Users\\YOUR_NAME\\AppData\\Local\\Android\\Sdk
GEMINI_API_KEY=YOUR_REAL_KEY
```

`local.properties` is excluded by `.gitignore`.

### Security warning

This direct-key build is appropriate only for a personal/development prototype. A key compiled into an APK can ultimately be extracted from that APK. Do not publish a production app with an unrestricted secret embedded in the client. For public distribution, keep the existing `AiService` boundary and replace the implementation with a secure backend/proxy, or migrate to Google's Android-oriented protected client architecture.

## Build

Requirements on the build machine:

- Android Studio / Android SDK 37
- JDK 17 or a compatible JDK supported by the configured Android Gradle Plugin
- internet access for the first Gradle/dependency download
- a valid `GEMINI_API_KEY` in `local.properties`

From the project root:

### Windows

```bat
gradlew.bat :app:assembleDebug
```

### macOS / Linux

```bash
./gradlew :app:assembleDebug
```

Expected APK location after a successful build:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Open the root directory in Android Studio if you prefer to sync/build there.

## Gradle wrapper note

The execution environment used to generate this project did not contain an Android SDK and could not resolve external hosts. Because the standard Gradle wrapper JAR could not be downloaded there, the repository includes a small source-generated bootstrap JAR at `gradle/wrapper/gradle-wrapper.jar`. It reads `gradle-wrapper.properties`, downloads Gradle 9.5.0 on a normal networked machine, extracts it into `GRADLE_USER_HOME`, and starts Gradle. The distribution URL remains in the normal wrapper properties file.

If Android Studio replaces/regenerates the wrapper with the standard Gradle wrapper, that is also fine.

## Persistence and privacy

- Conversations are stored locally with Room.
- Attached photos are copied to the application's private internal files directory.
- Room stores only file paths/metadata, not huge Base64 blobs.
- Deleting a conversation also deletes its saved local images.
- No accounts, cloud chat database, analytics, ads, or tracking were added.
- `allowBackup=false` is used to avoid silently backing up private app data through Android backup.
- Photos leave the device only as part of the Gemini API request required to answer the task.

## Image handling

The app:

- accepts one image per individual message;
- uses the system Photo Picker, so broad storage permission is not requested;
- captures a full-resolution camera image through a `FileProvider` URI;
- handles cancellation without creating a conversation;
- decodes on an IO dispatcher;
- applies EXIF orientation where needed;
- accepts formats the Android decoder supports, including common JPEG/PNG/WEBP and HEIF/HEIC on capable Android versions;
- limits extremely large images to a maximum long side of 2560 px and saves a high-quality JPEG copy in private app storage.

## Conversation context

Room is the source of truth. Before every AI request, the repository reconstructs prior usable turns from the stored conversation, including image attachments when needed. That means a reopened task can still understand follow-ups such as **„Uradi sada pod v).“** when the original image is part of the relevant history.

Failed requests keep the user's message/image and can be retried without inserting a duplicate visible user message. A pending message is also recovered after process recreation where practical.

## Error handling

The UI contains Serbian messages for:

- no internet;
- temporary network/API failure;
- quota/rate limit (429);
- invalid/missing API key;
- retrying a failed request.

It does not invent a quota reset time.

## Project structure

```text
app/src/main/java/com/resizadatak/app/
├── data/local        Room database, DAO, entities
├── data/media        private image import/camera processing
├── data/remote       AiService + Gemini implementation
├── data/repository   persistence/context/retry orchestration
├── di                small manual app container
└── ui
    ├── chat
    ├── components
    ├── home
    ├── navigation
    ├── task
    └── theme
```

## Build status of the generation environment

Static project checks were run (XML parsing, required-file checks, no TODO/FIXME placeholders, no embedded-looking Gemini key, no Serbian Cyrillic in the main UI source/resources). A real Android Gradle build could not be completed in the generation sandbox because it has no Android SDK and DNS/network access is blocked, so Gradle cannot download its distribution or Maven dependencies. See `BUILD_STATUS.md` and `build-attempt.log` for the exact status.

The source project is therefore ready for Android Studio/Gradle on a normal development machine, but the APK is **not claimed as locally compiled or device-tested** in this sandbox.

## GitHub Actions build
The repository includes `.github/workflows/build-apk.yml`. Add a repository Actions secret named `GEMINI_API_KEY`, then push to `main` or run the workflow manually. The resulting debug APK is uploaded as the `ResiZadatak-debug-apk` artifact.
