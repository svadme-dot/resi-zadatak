#!/usr/bin/env python3
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/resizadatak/app/MainActivity.kt",
    "app/src/main/java/com/resizadatak/app/data/local/AppDatabase.kt",
    "app/src/main/java/com/resizadatak/app/data/remote/GeminiAiService.kt",
    "app/src/main/java/com/resizadatak/app/data/repository/ChatRepository.kt",
    "app/src/main/java/com/resizadatak/app/ui/navigation/ResiZadatakApp.kt",
]
errors = []

for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required file: {rel}")

for xml in ROOT.rglob("*.xml"):
    try:
        ET.parse(xml)
    except Exception as exc:
        errors.append(f"Invalid XML {xml.relative_to(ROOT)}: {exc}")

text_files = [p for p in ROOT.rglob("*") if p.is_file() and p.suffix in {".kt", ".kts", ".xml", ".properties", ".md"}]
for p in text_files:
    text = p.read_text(encoding="utf-8", errors="ignore")
    if p.name not in {"SPECIFICATION.md", "README.md", "BUILD_STATUS.md"}:
        if "TODO" in text or "FIXME" in text:
            errors.append(f"TODO/FIXME found in {p.relative_to(ROOT)}")
    if re.search(r"AIza[0-9A-Za-z_-]{20,}", text):
        errors.append(f"Possible embedded Google API key in {p.relative_to(ROOT)}")

main_sources = list((ROOT / "app/src/main/java").rglob("*.kt")) + list((ROOT / "app/src/main/res").rglob("*.xml"))
for p in main_sources:
    text = p.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"[А-Яа-яЁё]", text):
        errors.append(f"Cyrillic found in app main source/resource: {p.relative_to(ROOT)}")

gemini = (ROOT / "app/src/main/java/com/resizadatak/app/data/remote/GeminiAiService.kt").read_text(encoding="utf-8")
for needle in [
    'MODEL_ID = "gemini-3.7-flash"',
    'ThinkingLevel("high")',
    '.codeExecution(',
    '.includeThoughts(false)',
]:
    if needle not in gemini:
        errors.append(f"Gemini configuration missing: {needle}")

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
for permission in ["READ_EXTERNAL_STORAGE", "READ_MEDIA_IMAGES", "WRITE_EXTERNAL_STORAGE"]:
    if permission in manifest:
        errors.append(f"Unnecessary broad storage/media permission present: {permission}")

if not (ROOT / ".gitignore").read_text(encoding="utf-8").splitlines().count("local.properties"):
    errors.append("local.properties is not explicitly gitignored")

if errors:
    print("PROJECT CHECK FAILED")
    for err in errors:
        print(f"- {err}")
    sys.exit(1)

print("PROJECT CHECK PASSED")
print(f"Files: {sum(1 for p in ROOT.rglob('*') if p.is_file())}")
print("Gemini: gemini-3.7-flash / thinking=high / code execution=enabled")
print("UI source/resources: Serbian Latin check passed")
