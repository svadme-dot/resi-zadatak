package com.resizadatak.app.data.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt


data class StoredImage(
    val path: String,
    val mimeType: String = "image/jpeg",
    val width: Int,
    val height: Int
)

data class CameraCapture(val file: File, val uri: Uri)

class ImageStore(private val context: Context) {
    private val imagesDir = File(context.filesDir, "chat_images").apply { mkdirs() }
    private val cameraDir = File(context.cacheDir, "camera").apply { mkdirs() }

    fun createCameraCapture(): CameraCapture {
        val file = File(cameraDir, PENDING_CAMERA_FILE)
        runCatching { file.delete() }
        file.parentFile?.mkdirs()
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        return CameraCapture(file, uri)
    }

    /** Reconstructs the pending capture after configuration/process recreation. */
    fun pendingCameraCapture(): CameraCapture? {
        val file = File(cameraDir, PENDING_CAMERA_FILE)
        if (!file.exists()) return null
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        return CameraCapture(file, uri)
    }

    fun discardCameraCapture(capture: CameraCapture?) {
        capture?.file?.delete()
    }

    suspend fun importUri(uri: Uri): StoredImage = withContext(Dispatchers.IO) {
        val bitmap = decodeForUpload(uri)
            ?: error("Fotografija nije mogla da se pročita.")
        saveBitmap(bitmap).also {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    suspend fun importCameraCapture(capture: CameraCapture): StoredImage = withContext(Dispatchers.IO) {
        try {
            val bitmap = decodeForUpload(Uri.fromFile(capture.file))
                ?: error("Fotografija nije mogla da se pročita.")
            saveBitmap(bitmap).also {
                if (!bitmap.isRecycled) bitmap.recycle()
            }
        } finally {
            capture.file.delete()
        }
    }

    fun delete(path: String) {
        runCatching { File(path).delete() }
    }

    private fun saveBitmap(bitmap: Bitmap): StoredImage {
        val output = File(imagesDir, "img_${UUID.randomUUID()}.jpg")
        FileOutputStream(output).use { stream ->
            check(bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream))
        }
        return StoredImage(output.absolutePath, "image/jpeg", bitmap.width, bitmap.height)
    }

    private fun decodeForUpload(uri: Uri): Bitmap? {
        return if (Build.VERSION.SDK_INT >= 28) decodeImageDecoder(uri) else decodeLegacy(uri)
    }

    @androidx.annotation.RequiresApi(28)
    private fun decodeImageDecoder(uri: Uri): Bitmap? {
        val source = if (uri.scheme == "file") {
            ImageDecoder.createSource(File(requireNotNull(uri.path)))
        } else {
            ImageDecoder.createSource(context.contentResolver, uri)
        }
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val size = info.size
            val longest = max(size.width, size.height)
            if (longest > MAX_LONG_SIDE) {
                val scale = MAX_LONG_SIDE.toFloat() / longest
                decoder.setTargetSize(
                    (size.width * scale).roundToInt().coerceAtLeast(1),
                    (size.height * scale).roundToInt().coerceAtLeast(1)
                )
            }
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    private fun decodeLegacy(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_LONG_SIDE * 2) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bitmap = open(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = runCatching {
            open(uri)?.use { ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            ) }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL

        val matrix = Matrix().apply {
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { postScale(-1f, 1f); postRotate(270f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { postScale(-1f, 1f); postRotate(90f) }
            }
        }
        if (!matrix.isIdentity) {
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (rotated !== bitmap) bitmap.recycle()
            bitmap = rotated
        }

        val longest = max(bitmap.width, bitmap.height)
        if (longest > MAX_LONG_SIDE) {
            val scale = MAX_LONG_SIDE.toFloat() / longest
            val scaled = Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).roundToInt().coerceAtLeast(1),
                (bitmap.height * scale).roundToInt().coerceAtLeast(1),
                true
            )
            if (scaled !== bitmap) bitmap.recycle()
            bitmap = scaled
        }
        return bitmap
    }

    private fun open(uri: Uri) = if (uri.scheme == "file") {
        File(requireNotNull(uri.path)).inputStream()
    } else {
        context.contentResolver.openInputStream(uri)
    }

    companion object {
        const val MAX_LONG_SIDE = 2560
        private const val PENDING_CAMERA_FILE = "pending_capture.jpg"
    }
}
