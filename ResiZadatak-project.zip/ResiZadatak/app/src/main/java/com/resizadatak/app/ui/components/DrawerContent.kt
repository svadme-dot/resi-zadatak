package com.resizadatak.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.resizadatak.app.data.local.ChatEntity
import java.util.Calendar

@Composable
fun DrawerContent(
    chats: List<ChatEntity>,
    onAddTask: () -> Unit,
    onNewChat: () -> Unit,
    onOpenChat: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var renameChat by remember { mutableStateOf<ChatEntity?>(null) }
    var deleteChat by remember { mutableStateOf<ChatEntity?>(null) }

    ModalDrawerSheet(Modifier.widthIn(max = 340.dp)) {
        Text(
            "Reši zadatak",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(24.dp, 26.dp, 24.dp, 14.dp)
        )
        Button(
            onClick = onAddTask,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(min = 52.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Dodaj novi zadatak")
        }
        TextButton(
            onClick = onNewChat,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(min = 48.dp)
        ) { Text("Novi chat") }
        HorizontalDivider(Modifier.padding(vertical = 10.dp))
        Text(
            "Prethodni razgovori",
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        val groups = chats.groupBy { groupName(it.updatedAt) }
        LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = true)) {
            listOf("Danas", "Juče", "Ranije").forEach { group ->
                val groupChats = groups[group].orEmpty()
                if (groupChats.isNotEmpty()) {
                    item(group) {
                        Text(
                            group,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp, 14.dp, 16.dp, 4.dp)
                        )
                    }
                    items(groupChats, key = { it.id }) { chat ->
                        DrawerChatRow(
                            chat = chat,
                            onOpen = { onOpenChat(chat.id) },
                            onRename = { renameChat = chat },
                            onDelete = { deleteChat = chat }
                        )
                    }
                }
            }
        }
    }

    renameChat?.let { chat ->
        var title by remember(chat.id) { mutableStateOf(chat.title) }
        AlertDialog(
            onDismissRequest = { renameChat = null },
            title = { Text("Preimenuj razgovor") },
            text = {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it.take(55) },
                    singleLine = true,
                    label = { Text("Naziv") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRename(chat.id, title)
                    renameChat = null
                }, enabled = title.isNotBlank()) { Text("Sačuvaj") }
            },
            dismissButton = { TextButton(onClick = { renameChat = null }) { Text("Otkaži") } }
        )
    }

    deleteChat?.let { chat ->
        AlertDialog(
            onDismissRequest = { deleteChat = null },
            title = { Text("Obriši razgovor?") },
            text = { Text("Ovaj razgovor i njegove slike biće trajno obrisani sa uređaja.") },
            confirmButton = {
                TextButton(onClick = { onDelete(chat.id); deleteChat = null }) { Text("Obriši") }
            },
            dismissButton = { TextButton(onClick = { deleteChat = null }) { Text("Otkaži") } }
        )
    }
}

@Composable
private fun DrawerChatRow(
    chat: ChatEntity,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(start = 24.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(chat.title, modifier = Modifier.weight(1f), maxLines = 2, style = MaterialTheme.typography.bodyMedium)
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Opcije razgovora") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Preimenuj") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Obriši") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

private fun groupName(time: Long): String {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = time }
    fun sameDay(a: Calendar, b: Calendar) = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (sameDay(now, date)) return "Danas"
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    return if (sameDay(yesterday, date)) "Juče" else "Ranije"
}
