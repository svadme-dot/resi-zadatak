package com.resizadatak.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.resizadatak.app.ui.navigation.ResiZadatakApp
import com.resizadatak.app.ui.theme.ResiZadatakTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as ResiZadatakApplication).container
        setContent {
            ResiZadatakTheme { ResiZadatakApp(container) }
        }
    }
}
