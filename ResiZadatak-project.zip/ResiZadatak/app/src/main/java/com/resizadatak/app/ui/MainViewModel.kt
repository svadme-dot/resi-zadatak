package com.resizadatak.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.resizadatak.app.data.local.ChatEntity
import com.resizadatak.app.data.local.ChatType
import com.resizadatak.app.data.media.CameraCapture
import com.resizadatak.app.data.media.ImageStore
import com.resizadatak.app.data.media.StoredImage
import com.resizadatak.app.data.repository.ChatRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: ChatRepository,
    private val imageStore: ImageStore
) : ViewModel() {
    val chats: StateFlow<List<ChatEntity>> = repository.observeChats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _newTaskImage = MutableStateFlow<StoredImage?>(null)
    val newTaskImage = _newTaskImage.asStateFlow()

    private val _processingImage = MutableStateFlow(false)
    val processingImage = _processingImage.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice = _notice.asStateFlow()

    fun consumeNotice() { _notice.value = null }

    fun importForNewTask(uri: Uri) {
        viewModelScope.launch {
            _processingImage.value = true
            try {
                val old = _newTaskImage.value
                val imported = imageStore.importUri(uri)
                _newTaskImage.value = imported
                old?.let { imageStore.delete(it.path) }
            } catch (_: Throwable) {
                _notice.value = "Fotografija nije mogla da se otvori. Pokušaj sa drugom slikom."
            } finally {
                _processingImage.value = false
            }
        }
    }

    fun importCameraForNewTask(capture: CameraCapture) {
        viewModelScope.launch {
            _processingImage.value = true
            try {
                val old = _newTaskImage.value
                val imported = imageStore.importCameraCapture(capture)
                _newTaskImage.value = imported
                old?.let { imageStore.delete(it.path) }
            } catch (_: Throwable) {
                imageStore.discardCameraCapture(capture)
                _notice.value = "Fotografija nije mogla da se sačuva. Pokušaj ponovo."
            } finally {
                _processingImage.value = false
            }
        }
    }

    fun clearNewTaskImage(deleteFile: Boolean = true) {
        val old = _newTaskImage.value
        _newTaskImage.value = null
        if (deleteFile) old?.let { imageStore.delete(it.path) }
    }

    fun createTask(text: String, onCreated: (String, String) -> Unit) {
        val image = _newTaskImage.value
        if (image == null && text.isBlank()) return
        viewModelScope.launch {
            val (chatId, messageId) = repository.createConversationWithMessage(ChatType.TASK, text, image)
            _newTaskImage.value = null // ownership transferred to the conversation
            onCreated(chatId, messageId)
        }
    }

    fun createTextChat(text: String, onCreated: (String, String) -> Unit) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val (chatId, messageId) = repository.createConversationWithMessage(ChatType.CHAT, text, null)
            onCreated(chatId, messageId)
        }
    }

    fun renameChat(chatId: String, title: String) = viewModelScope.launch { repository.rename(chatId, title) }
    fun deleteChat(chatId: String) = viewModelScope.launch { repository.delete(chatId) }

    class Factory(
        private val repository: ChatRepository,
        private val imageStore: ImageStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repository, imageStore) as T
    }
}
