package com.resizadatak.app.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.resizadatak.app.data.local.ChatEntity
import com.resizadatak.app.data.local.ChatType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    chats: List<ChatEntity>,
    onMenu: () -> Unit,
    onAddTask: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reši zadatak", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Otvori meni") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(42.dp))
            ElevatedCard(
                onClick = onAddTask,
                modifier = Modifier.fillMaxWidth().heightIn(min = 190.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(58.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("+ Dodaj novi zadatak", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Izaberi fotografiju zadatka ili ga slikaj kamerom.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center
                    )
                }
            }

            val recent = chats.filter { it.type == ChatType.TASK }.take(3)
            if (recent.isNotEmpty()) {
                Spacer(Modifier.height(34.dp))
                Text("Nedavni zadaci", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                recent.forEach { chat ->
                    Surface(
                        Modifier.fillMaxWidth().clickable { onOpenChat(chat.id) },
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(chat.title, Modifier.padding(horizontal = 14.dp, vertical = 13.dp), maxLines = 2)
                    }
                }
            }
        }
    }
}
