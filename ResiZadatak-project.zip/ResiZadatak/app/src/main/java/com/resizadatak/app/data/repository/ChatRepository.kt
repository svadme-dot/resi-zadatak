package com.resizadatak.app.data.repository

import com.resizadatak.app.data.local.*
import com.resizadatak.app.data.media.ImageStore
import com.resizadatak.app.data.media.StoredImage
import com.resizadatak.app.data.remote.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class ChatRepository(
    private val dao: AppDao,
    private val aiService: AiService,
    private val imageStore: ImageStore
) {
    private val sendMutex = Mutex()

    fun observeChats(): Flow<List<ChatEntity>> = dao.observeChats()
    fun observeChat(chatId: String): Flow<ChatEntity?> = dao.observeChat(chatId)
    fun observeMessages(chatId: String): Flow<List<MessageWithAttachments>> = dao.observeMessages(chatId)

    suspend fun createConversationWithMessage(
        type: ChatType,
        text: String,
        image: StoredImage?
    ): Pair<String, String> {
        val now = System.currentTimeMillis()
        val chatId = UUID.randomUUID().toString()
        val title = makeTitle(text, image != null)
        dao.upsertChat(ChatEntity(chatId, type, title, now, now))
        val messageId = addUserMessage(chatId, text, image)
        return chatId to messageId
    }

    suspend fun addUserMessage(chatId: String, text: String, image: StoredImage?): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        dao.upsertMessage(
            MessageEntity(
                id = id,
                chatId = chatId,
                role = MessageRole.USER,
                text = text.trim(),
                timestamp = now,
                status = MessageStatus.PENDING
            )
        )
        image?.let {
            dao.upsertAttachment(
                AttachmentEntity(
                    id = UUID.randomUUID().toString(),
                    messageId = id,
                    localPath = it.path,
                    mimeType = it.mimeType,
                    width = it.width,
                    height = it.height
                )
            )
        }
        dao.touchChat(chatId, now)
        return id
    }

    suspend fun sendToAi(chatId: String, userMessageId: String) {
        sendMutex.withLock {
            if (dao.replyCount(chatId, userMessageId) > 0) {
                dao.updateMessageStatus(userMessageId, MessageStatus.SENT, null)
                return
            }
            val userMessage = dao.getMessage(userMessageId) ?: return
            dao.updateMessageStatus(userMessageId, MessageStatus.PENDING, null)

            val turns = dao.getMessages(chatId).mapNotNull { row ->
                val m = row.message
                if (m.timestamp > userMessage.timestamp && m.id != userMessageId) return@mapNotNull null
                val shouldInclude = when (m.role) {
                    MessageRole.ASSISTANT -> m.status == MessageStatus.SENT
                    MessageRole.USER -> m.status == MessageStatus.SENT || m.id == userMessageId
                }
                if (!shouldInclude) return@mapNotNull null
                val attachment = row.attachments.firstOrNull()
                AiTurn(m.role, m.text, attachment?.localPath, attachment?.mimeType)
            }

            try {
                val answer = aiService.generate(turns)
                val now = System.currentTimeMillis()
                dao.upsertMessage(
                    MessageEntity(
                        id = UUID.randomUUID().toString(),
                        chatId = chatId,
                        role = MessageRole.ASSISTANT,
                        text = answer,
                        timestamp = now,
                        status = MessageStatus.SENT,
                        replyToMessageId = userMessageId
                    )
                )
                dao.updateMessageStatus(userMessageId, MessageStatus.SENT, null)
                dao.touchChat(chatId, now)
            } catch (e: AiServiceException) {
                dao.updateMessageStatus(userMessageId, MessageStatus.ERROR, e.kind.name)
            } catch (_: Throwable) {
                dao.updateMessageStatus(userMessageId, MessageStatus.ERROR, AiErrorKind.UNKNOWN.name)
            }
        }
    }

    suspend fun retry(chatId: String, userMessageId: String) = sendToAi(chatId, userMessageId)

    suspend fun resumePending(chatId: String) {
        dao.getLatestPendingUserMessageId(chatId)?.let { sendToAi(chatId, it) }
    }

    suspend fun rename(chatId: String, newTitle: String) {
        val clean = newTitle.trim().take(55)
        if (clean.isNotBlank()) dao.renameChat(chatId, clean, System.currentTimeMillis())
    }

    suspend fun delete(chatId: String) {
        val chat = dao.getChat(chatId) ?: return
        val images = dao.getAttachmentsForChat(chatId).map { it.localPath }
        dao.deleteChat(chat)
        images.forEach(imageStore::delete)
    }

    private fun makeTitle(text: String, hasImage: Boolean): String {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        return when {
            clean.isNotBlank() -> clean.take(55).trimEnd('.', ' ', ',')
            hasImage -> "Zadatak sa slike"
            else -> "Novi chat"
        }
    }
}
