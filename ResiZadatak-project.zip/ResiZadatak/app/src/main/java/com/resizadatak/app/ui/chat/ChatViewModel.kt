package com.resizadatak.app.ui.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.resizadatak.app.data.local.*
import com.resizadatak.app.data.media.CameraCapture
import com.resizadatak.app.data.media.ImageStore
import com.resizadatak.app.data.media.StoredImage
import com.resizadatak.app.data.repository.ChatRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(
    val chatId: String,
    private val repository: ChatRepository,
    private val imageStore: ImageStore
) : ViewModel() {
    val chat: StateFlow<ChatEntity?> = repository.observeChat(chatId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val messages: StateFlow<List<MessageWithAttachments>> = repository.observeMessages(chatId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _draft = MutableStateFlow("")
    val draft = _draft.asStateFlow()
    private val _attachment = MutableStateFlow<StoredImage?>(null)
    val attachment = _attachment.asStateFlow()
    private val _processingImage = MutableStateFlow(false)
    val processingImage = _processingImage.asStateFlow()
    private val _notice = MutableStateFlow<String?>(null)
    val notice = _notice.asStateFlow()

    init {
        // If Android killed the process during an in-flight request, Room still contains
        // the pending user turn. Resume it once the conversation is reopened.
        viewModelScope.launch { repository.resumePending(chatId) }
    }

    fun setDraft(text: String) { _draft.value = text }
    fun consumeNotice() { _notice.value = null }

    fun importGallery(uri: Uri) {
        viewModelScope.launch {
            _processingImage.value = true
            try {
                val old = _attachment.value
                val imported = imageStore.importUri(uri)
                _attachment.value = imported
                old?.let { imageStore.delete(it.path) }
            } catch (_: Throwable) {
                _notice.value = "Fotografija nije mogla da se otvori."
            } finally { _processingImage.value = false }
        }
    }

    fun importCamera(capture: CameraCapture) {
        viewModelScope.launch {
            _processingImage.value = true
            try {
                val old = _attachment.value
                val imported = imageStore.importCameraCapture(capture)
                _attachment.value = imported
                old?.let { imageStore.delete(it.path) }
            } catch (_: Throwable) {
                imageStore.discardCameraCapture(capture)
                _notice.value = "Fotografija nije mogla da se sačuva."
            } finally { _processingImage.value = false }
        }
    }

    fun removeAttachment() {
        _attachment.value?.let { imageStore.delete(it.path) }
        _attachment.value = null
    }

    fun send() {
        val text = _draft.value.trim()
        val image = _attachment.value
        if (text.isBlank() && image == null) return
        _draft.value = ""
        _attachment.value = null
        viewModelScope.launch {
            val id = repository.addUserMessage(chatId, text, image)
            repository.sendToAi(chatId, id)
        }
    }

    fun sendExistingMessage(messageId: String) {
        viewModelScope.launch { repository.sendToAi(chatId, messageId) }
    }

    fun retry(messageId: String) {
        viewModelScope.launch { repository.retry(chatId, messageId) }
    }

    override fun onCleared() {
        _attachment.value?.let { imageStore.delete(it.path) }
        super.onCleared()
    }

    class Factory(
        private val chatId: String,
        private val repository: ChatRepository,
        private val imageStore: ImageStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ChatViewModel(chatId, repository, imageStore) as T
    }
}
