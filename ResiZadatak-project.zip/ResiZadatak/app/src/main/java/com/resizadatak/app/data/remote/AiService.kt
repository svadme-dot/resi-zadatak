package com.resizadatak.app.data.remote

import com.resizadatak.app.data.local.MessageRole

data class AiTurn(
    val role: MessageRole,
    val text: String,
    val imagePath: String? = null,
    val imageMimeType: String? = null
)

enum class AiErrorKind { NO_INTERNET, RATE_LIMIT, INVALID_KEY, TEMPORARY, UNKNOWN }

class AiServiceException(val kind: AiErrorKind, cause: Throwable? = null) : RuntimeException(cause)

interface AiService {
    suspend fun generate(turns: List<AiTurn>): String
}
