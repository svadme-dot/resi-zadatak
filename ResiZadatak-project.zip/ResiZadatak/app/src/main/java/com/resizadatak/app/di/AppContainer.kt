package com.resizadatak.app.di

import android.content.Context
import com.resizadatak.app.data.local.AppDatabase
import com.resizadatak.app.data.media.ImageStore
import com.resizadatak.app.data.remote.GeminiAiService
import com.resizadatak.app.data.repository.ChatRepository

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val database = AppDatabase.create(appContext)
    val imageStore = ImageStore(appContext)
    val aiService = GeminiAiService(appContext)
    val chatRepository = ChatRepository(database.dao(), aiService, imageStore)
}
