package com.resizadatak.app.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Base64
import com.resizadatak.app.BuildConfig
import com.resizadatak.app.data.local.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object GeminiConfig {
    const val MODEL_ID = "gemini-3.7-flash"
    private const val API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
    val endpoint: String get() = "$API_BASE/$MODEL_ID:generateContent"
}

class GeminiAiService(private val context: Context) : AiService {
    override suspend fun generate(turns: List<AiTurn>): String = withContext(Dispatchers.IO) {
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            throw@withContext AiServiceException(AiErrorKind.INVALID_KEY)
        }
        if (!hasInternet()) {
            throw@withContext AiServiceException(AiErrorKind.NO_INTERNET)
        }

        try {
            val request = buildRequest(turns)
            val connection = (URL(GeminiConfig.endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30_000
                readTimeout = 180_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
            }

            connection.outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write(request.toString())
            }

            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)
                ?.use { it.readText() }
                .orEmpty()

            if (status !in 200..299) {
                throw httpError(status, body)
            }

            parseTextResponse(body)
                .takeUnless { it.isBlank() }
                ?: throw AiServiceException(AiErrorKind.TEMPORARY)
        } catch (e: AiServiceException) {
            throw e
        } catch (e: Throwable) {
            throw classify(e)
        }
    }

    private fun buildRequest(turns: List<AiTurn>): JSONObject {
        val contents = JSONArray()

        turns.forEach { turn ->
            val parts = JSONArray()

            turn.imagePath?.let { imagePath ->
                val bytes = File(imagePath).readBytes()
                val inlineData = JSONObject()
                    .put("mimeType", turn.imageMimeType ?: "image/jpeg")
                    .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                parts.put(JSONObject().put("inlineData", inlineData))
            }

            if (turn.text.isNotBlank()) {
                parts.put(JSONObject().put("text", turn.text))
            }
            if (parts.length() == 0) {
                parts.put(JSONObject().put("text", "Nastavi."))
            }

            contents.put(
                JSONObject()
                    .put("role", if (turn.role == MessageRole.USER) "user" else "model")
                    .put("parts", parts)
            )
        }

        val systemInstruction = JSONObject().put(
            "parts",
            JSONArray().put(JSONObject().put("text", SYSTEM_INSTRUCTION))
        )

        val generationConfig = JSONObject()
            .put(
                "thinkingConfig",
                JSONObject()
                    .put("thinkingLevel", "HIGH")
                    .put("includeThoughts", false)
            )
            .put("maxOutputTokens", 16_384)

        val tools = JSONArray().put(
            JSONObject().put("codeExecution", JSONObject())
        )

        return JSONObject()
            .put("systemInstruction", systemInstruction)
            .put("contents", contents)
            .put("tools", tools)
            .put("generationConfig", generationConfig)
    }

    private fun parseTextResponse(body: String): String {
        val root = JSONObject(body)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""

        val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val output = StringBuilder()

        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            val text = part.optString("text", "").trim()
            if (text.isNotEmpty()) {
                if (output.isNotEmpty()) output.append("\n")
                output.append(text)
            }
            // executableCode and codeExecutionResult are intentionally not shown to the user.
        }
        return output.toString().trim()
    }

    private fun httpError(status: Int, body: String): AiServiceException {
        val kind = when (status) {
            401, 403 -> AiErrorKind.INVALID_KEY
            429 -> AiErrorKind.RATE_LIMIT
            500, 502, 503, 504 -> AiErrorKind.TEMPORARY
            else -> {
                val lower = body.lowercase()
                when {
                    "api key" in lower && ("invalid" in lower || "expired" in lower) -> AiErrorKind.INVALID_KEY
                    "quota" in lower || "rate limit" in lower || "resource_exhausted" in lower -> AiErrorKind.RATE_LIMIT
                    else -> AiErrorKind.UNKNOWN
                }
            }
        }
        return AiServiceException(kind, IOException("Gemini HTTP $status: $body"))
    }

    private fun classify(error: Throwable): AiServiceException {
        val chain = generateSequence(error) { it.cause }.toList()
        if (chain.any { it is IOException }) return AiServiceException(AiErrorKind.NO_INTERNET, error)
        val text = chain.joinToString(" ") { it.message.orEmpty() }.lowercase()
        return when {
            "429" in text || "resource_exhausted" in text || "quota" in text || "rate limit" in text ->
                AiServiceException(AiErrorKind.RATE_LIMIT, error)
            "401" in text || "403" in text || "api key" in text && ("invalid" in text || "expired" in text) ->
                AiServiceException(AiErrorKind.INVALID_KEY, error)
            "500" in text || "502" in text || "503" in text || "504" in text || "timeout" in text ->
                AiServiceException(AiErrorKind.TEMPORARY, error)
            else -> AiServiceException(AiErrorKind.UNKNOWN, error)
        }
    }

    private fun hasInternet(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    companion object {
        val SYSTEM_INSTRUCTION = """
            Reši zadatak i objasni na srpskom jeziku, latinicom, korak po korak tako da svako može da razume. Prikaži jasan postupak i proveri konačan rezultat.

            Ako fotografija sadrži više zadataka, rešavaj samo zadatak, podzadatak ili deo koji je korisnik izričito tražio. Ne rešavaj automatski sve zadatke koji se vide na fotografiji.

            Na primer, ako se na fotografiji vide zadaci 350–364, a korisnik napiše „Reši mi 358. pod a) i b)“, rešavaj samo 358. pod a) i b).

            Ako fotografija sadrži više zadataka, a korisnik nije naveo koji želi da reši, nemoj nasumično birati niti rešavati sve. Pitaj korisnika koji broj zadatka ili koji deo želi.

            Ako se na fotografiji jasno vidi samo jedan zadatak i korisnik nije dodao posebnu tekstualnu instrukciju, možeš rešiti taj zadatak.

            Ako neki deo fotografije nije dovoljno čitljiv, nemoj izmišljati tekst. Reci korisniku šta nije čitljivo i zamoli ga da napravi jasniju fotografiju.

            Koristi metode i objašnjenja primerene školskom uzrastu. Nemoj nepotrebno koristiti fakultetske ili napredne metode ako se zadatak može rešiti standardnim školskim postupkom.

            Ako korisnik traži jednostavnije objašnjenje, objasni jednostavnije. Ako traži samo rezultat, odgovori kraće. Ako pita za određeni prethodni korak, odgovori u kontekstu trenutnog zadatka.

            Jasno odvoji postupak od konačnog odgovora. Proveri račun pre konačnog odgovora kada je to moguće.
            Za fiziku, kada odgovara zadatku, jasno prikaži dato, formulu, račun, rezultat i jedinice. Za geometriju koristi standardni školski postupak.
        """.trimIndent()
    }
}
