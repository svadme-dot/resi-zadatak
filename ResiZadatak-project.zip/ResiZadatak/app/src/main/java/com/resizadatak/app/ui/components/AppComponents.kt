package com.resizadatak.app.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

@Composable
fun FileImage(
    path: String,
    modifier: Modifier = Modifier,
    maxDecodeSide: Int = 1400,
    contentScale: ContentScale = ContentScale.Fit,
    contentDescription: String? = "Fotografija zadatka"
) {
    val bitmap by rememberFileBitmap(path, maxDecodeSide)
    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    } else {
        Box(modifier, contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
private fun rememberFileBitmap(path: String, maxSide: Int): State<Bitmap?> =
    produceState<Bitmap?>(initialValue = null, path, maxSide) {
        value = withContext(Dispatchers.IO) {
            val f = File(path)
            if (!f.exists()) return@withContext null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (max(bounds.outWidth / sample, bounds.outHeight / sample) > maxSide * 2) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }

@Composable
fun FullScreenImageViewer(path: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offsetX by remember { mutableFloatStateOf(0f) }
        var offsetY by remember { mutableFloatStateOf(0f) }
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.scrim) {
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        if (scale == 1f) {
                            offsetX = 0f; offsetY = 0f
                        } else {
                            offsetX += pan.x; offsetY += pan.y
                        }
                    }
                }
            ) {
                FileImage(
                    path = path,
                    maxDecodeSide = 2600,
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale; scaleY = scale
                        translationX = offsetX; translationY = offsetY
                    },
                    contentScale = ContentScale.Fit
                )
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                ) {
                    Icon(Icons.Default.Close, "Zatvori", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    SelectionContainer {
        Text(
            text = simpleMarkdown(text),
            modifier = modifier,
            style = MaterialTheme.typography.bodyLarge,
            lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.18f
        )
    }
}

private fun simpleMarkdown(source: String): AnnotatedString = buildAnnotatedString {
    val cleaned = source.lineSequence().joinToString("\n") { line ->
        line.replace(Regex("^#{1,4}\\s+"), "")
    }
    var i = 0
    var bold = false
    var chunkStart = 0
    while (i < cleaned.length) {
        if (i + 1 < cleaned.length && cleaned[i] == '*' && cleaned[i + 1] == '*') {
            if (chunkStart < i) {
                if (bold) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(cleaned.substring(chunkStart, i)) }
                else append(cleaned.substring(chunkStart, i))
            }
            bold = !bold
            i += 2
            chunkStart = i
        } else i++
    }
    if (chunkStart < cleaned.length) {
        if (bold) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(cleaned.substring(chunkStart)) }
        else append(cleaned.substring(chunkStart))
    }
}

@Composable
fun ImagePreviewCard(path: String, onRemove: (() -> Unit)? = null, onOpen: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 360.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onOpen)
    ) {
        FileImage(path, Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 360.dp))
        if (onRemove != null) {
            FilledIconButton(
                onClick = onRemove,
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).size(44.dp)
            ) { Icon(Icons.Default.Close, "Ukloni fotografiju") }
        }
    }
}
