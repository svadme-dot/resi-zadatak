package com.resizadatak.app

import android.app.Application
import com.resizadatak.app.di.AppContainer

class ResiZadatakApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
