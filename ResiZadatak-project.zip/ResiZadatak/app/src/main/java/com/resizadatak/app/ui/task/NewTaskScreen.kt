package com.resizadatak.app.ui.task

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.resizadatak.app.data.media.StoredImage
import com.resizadatak.app.ui.components.FullScreenImageViewer
import com.resizadatak.app.ui.components.ImagePreviewCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewTaskScreen(
    image: StoredImage?,
    onBack: () -> Unit,
    onRemoveImage: () -> Unit,
    onAddImage: () -> Unit,
    onSend: (String) -> Unit
) {
    var text by rememberSaveable { mutableStateOf("") }
    var viewing by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Novi zadatak", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Nazad") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(20.dp)
        ) {
            if (image != null) {
                ImagePreviewCard(image.path, onRemove = onRemoveImage, onOpen = { viewing = true })
                Spacer(Modifier.height(18.dp))
            } else {
                OutlinedButton(onClick = onAddImage, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) {
                    Text("Dodaj fotografiju")
                }
                Spacer(Modifier.height(18.dp))
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                placeholder = { Text("Napiši šta želiš da rešim...") }
            )
            Text(
                "Npr. „Reši mi 358. pod a) i b).“",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 7.dp, start = 4.dp)
            )
            Spacer(Modifier.weight(1f))
            Button(
                onClick = { onSend(text) },
                enabled = image != null || text.isNotBlank(),
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp)
            ) { Text("Pošalji", style = MaterialTheme.typography.titleMedium) }
        }
    }

    if (viewing && image != null) FullScreenImageViewer(image.path) { viewing = false }
}
