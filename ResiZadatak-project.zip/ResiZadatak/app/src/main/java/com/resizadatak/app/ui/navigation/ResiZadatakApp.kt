package com.resizadatak.app.ui.navigation

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.resizadatak.app.data.media.CameraCapture
import com.resizadatak.app.di.AppContainer
import com.resizadatak.app.ui.MainViewModel
import com.resizadatak.app.ui.chat.*
import com.resizadatak.app.ui.components.*
import com.resizadatak.app.ui.home.HomeScreen
import com.resizadatak.app.ui.task.NewTaskScreen
import kotlinx.coroutines.launch

private const val HOME = "home"
private const val NEW_TASK = "new_task"
private const val NEW_CHAT = "new_chat"
private const val CHAT = "chat/{chatId}?initial={initial}"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResiZadatakApp(container: AppContainer) {
    val mainViewModel: MainViewModel = viewModel(
        factory = MainViewModel.Factory(container.chatRepository, container.imageStore)
    )
    val chats by mainViewModel.chats.collectAsState()
    val newTaskImage by mainViewModel.newTaskImage.collectAsState()
    val processing by mainViewModel.processingImage.collectAsState()
    val notice by mainViewModel.notice.collectAsState()

    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var sourceSheet by remember { mutableStateOf(false) }
    var cameraCapture by remember { mutableStateOf<CameraCapture?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) mainViewModel.importForNewTask(uri)
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val capture = cameraCapture ?: container.imageStore.pendingCameraCapture()
        cameraCapture = null
        if (success && capture != null) mainViewModel.importCameraForNewTask(capture)
        else container.imageStore.discardCameraCapture(capture)
    }

    LaunchedEffect(newTaskImage?.path) {
        if (newTaskImage != null && navController.currentDestination?.route != NEW_TASK) {
            navController.navigate(NEW_TASK)
        }
    }

    fun openChat(chatId: String, initial: String? = null) {
        val route = if (initial == null) "chat/$chatId" else "chat/$chatId?initial=$initial"
        navController.navigate(route)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(
                chats = chats,
                onAddTask = {
                    scope.launch { drawerState.close() }
                    sourceSheet = true
                },
                onNewChat = {
                    scope.launch { drawerState.close() }
                    navController.navigate(NEW_CHAT)
                },
                onOpenChat = { id ->
                    scope.launch { drawerState.close() }
                    openChat(id)
                },
                onRename = { id, title -> mainViewModel.renameChat(id, title) },
                onDelete = { id -> mainViewModel.deleteChat(id) }
            )
        }
    ) {
        NavHost(navController = navController, startDestination = HOME) {
            composable(HOME) {
                HomeScreen(
                    chats = chats,
                    onMenu = { scope.launch { drawerState.open() } },
                    onAddTask = { sourceSheet = true },
                    onOpenChat = { id -> openChat(id) }
                )
            }
            composable(NEW_TASK) {
                NewTaskScreen(
                    image = newTaskImage,
                    onBack = {
                        mainViewModel.clearNewTaskImage(deleteFile = true)
                        navController.popBackStack()
                    },
                    onRemoveImage = { mainViewModel.clearNewTaskImage(deleteFile = true) },
                    onAddImage = { sourceSheet = true },
                    onSend = { text ->
                        mainViewModel.createTask(text) { chatId, messageId ->
                            navController.navigate("chat/$chatId?initial=$messageId") {
                                popUpTo(NEW_TASK) { inclusive = true }
                            }
                        }
                    }
                )
            }
            composable(NEW_CHAT) {
                NewChatScreen(
                    onBack = { navController.popBackStack() },
                    onSend = { text ->
                        mainViewModel.createTextChat(text) { chatId, messageId ->
                            navController.navigate("chat/$chatId?initial=$messageId") {
                                popUpTo(NEW_CHAT) { inclusive = true }
                            }
                        }
                    }
                )
            }
            composable(
                route = CHAT,
                arguments = listOf(
                    navArgument("chatId") { type = NavType.StringType },
                    navArgument("initial") { type = NavType.StringType; nullable = true; defaultValue = null }
                )
            ) { entry ->
                val chatId = requireNotNull(entry.arguments?.getString("chatId"))
                val initial = entry.arguments?.getString("initial")
                val chatVm: ChatViewModel = viewModel(
                    key = "chat-$chatId",
                    factory = ChatViewModel.Factory(chatId, container.chatRepository, container.imageStore)
                )
                ChatScreen(
                    viewModel = chatVm,
                    imageStore = container.imageStore,
                    initialMessageId = initial,
                    onMenu = { scope.launch { drawerState.open() } }
                )
            }
        }
    }

    if (sourceSheet) {
        SourceChooserSheet(
            onDismiss = { sourceSheet = false },
            onGallery = {
                sourceSheet = false
                galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onCamera = {
                sourceSheet = false
                val capture = container.imageStore.createCameraCapture()
                cameraCapture = capture
                cameraLauncher.launch(capture.uri)
            }
        )
    }

    if (processing) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.32f)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Card { Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Pripremam fotografiju...")
                } }
            }
        }
    }

    if (notice != null) {
        AlertDialog(
            onDismissRequest = mainViewModel::consumeNotice,
            text = { Text(notice.orEmpty()) },
            confirmButton = { TextButton(onClick = mainViewModel::consumeNotice) { Text("U redu") } }
        )
    }
}
