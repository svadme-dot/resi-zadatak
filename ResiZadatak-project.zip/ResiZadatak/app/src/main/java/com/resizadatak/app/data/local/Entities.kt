package com.resizadatak.app.data.local

import androidx.room.*

enum class ChatType { TASK, CHAT }
enum class MessageRole { USER, ASSISTANT }
enum class MessageStatus { PENDING, SENT, ERROR }

class RoomConverters {
    @TypeConverter fun fromChatType(value: ChatType) = value.name
    @TypeConverter fun toChatType(value: String) = ChatType.valueOf(value)
    @TypeConverter fun fromRole(value: MessageRole) = value.name
    @TypeConverter fun toRole(value: String) = MessageRole.valueOf(value)
    @TypeConverter fun fromStatus(value: MessageStatus) = value.name
    @TypeConverter fun toStatus(value: String) = MessageStatus.valueOf(value)
}

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val type: ChatType,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(
        entity = ChatEntity::class,
        parentColumns = ["id"],
        childColumns = ["chatId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("chatId")]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val role: MessageRole,
    val text: String,
    val timestamp: Long,
    val status: MessageStatus,
    val errorKind: String? = null,
    val replyToMessageId: String? = null
)

@Entity(
    tableName = "attachments",
    foreignKeys = [ForeignKey(
        entity = MessageEntity::class,
        parentColumns = ["id"],
        childColumns = ["messageId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("messageId")]
)
data class AttachmentEntity(
    @PrimaryKey val id: String,
    val messageId: String,
    val localPath: String,
    val mimeType: String,
    val width: Int,
    val height: Int
)

data class MessageWithAttachments(
    @Embedded val message: MessageEntity,
    @Relation(parentColumn = "id", entityColumn = "messageId")
    val attachments: List<AttachmentEntity>
)
