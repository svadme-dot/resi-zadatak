package com.resizadatak.app.ui.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.resizadatak.app.data.local.*
import com.resizadatak.app.data.media.CameraCapture
import com.resizadatak.app.data.media.ImageStore
import com.resizadatak.app.data.remote.AiErrorKind
import com.resizadatak.app.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    imageStore: ImageStore,
    initialMessageId: String?,
    onMenu: () -> Unit
) {
    val chat by viewModel.chat.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val draft by viewModel.draft.collectAsState()
    val attachment by viewModel.attachment.collectAsState()
    val processingImage by viewModel.processingImage.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val listState = rememberLazyListState()
    var sourceSheet by remember { mutableStateOf(false) }
    var viewerPath by remember { mutableStateOf<String?>(null) }
    var cameraCapture by remember { mutableStateOf<CameraCapture?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.importGallery(uri)
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val capture = cameraCapture ?: imageStore.pendingCameraCapture()
        cameraCapture = null
        if (success && capture != null) viewModel.importCamera(capture)
        else imageStore.discardCameraCapture(capture)
    }

    LaunchedEffect(initialMessageId) {
        if (!initialMessageId.isNullOrBlank()) viewModel.sendExistingMessage(initialMessageId)
    }

    val sending = messages.any { it.message.role == MessageRole.USER && it.message.status == MessageStatus.PENDING }
    LaunchedEffect(messages.size, sending) {
        val count = listState.layoutInfo.totalItemsCount
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(chat?.title ?: "Razgovor", maxLines = 1, fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Otvori meni") } }
            )
        },
        bottomBar = {
            ChatComposer(
                draft = draft,
                attachmentPath = attachment?.path,
                placeholder = if (chat?.type == ChatType.TASK) "Pitaj nešto o ovom zadatku..." else "Napiši poruku...",
                sending = sending || processingImage,
                onDraft = viewModel::setDraft,
                onAttach = { sourceSheet = true },
                onRemoveAttachment = viewModel::removeAttachment,
                onOpenAttachment = { attachment?.path?.let { viewerPath = it } },
                onSend = viewModel::send
            )
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.message.id }) { row ->
                MessageBubble(
                    row = row,
                    onOpenImage = { viewerPath = it },
                    onRetry = { viewModel.retry(row.message.id) }
                )
            }
            if (sending) {
                item("loading") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text(if (chat?.type == ChatType.TASK) "Rešavam zadatak..." else "Razmišljam...")
                            }
                        }
                    }
                }
            }
        }
    }

    if (sourceSheet) {
        SourceChooserSheet(
            onDismiss = { sourceSheet = false },
            onGallery = {
                sourceSheet = false
                galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onCamera = {
                sourceSheet = false
                val capture = imageStore.createCameraCapture()
                cameraCapture = capture
                cameraLauncher.launch(capture.uri)
            }
        )
    }

    viewerPath?.let { path -> FullScreenImageViewer(path) { viewerPath = null } }

    if (notice != null) {
        AlertDialog(
            onDismissRequest = viewModel::consumeNotice,
            text = { Text(notice.orEmpty()) },
            confirmButton = { TextButton(onClick = viewModel::consumeNotice) { Text("U redu") } }
        )
    }
}

@Composable
private fun MessageBubble(
    row: MessageWithAttachments,
    onOpenImage: (String) -> Unit,
    onRetry: () -> Unit
) {
    val message = row.message
    val isUser = message.role == MessageRole.USER
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth(if (isUser) 0.84f else 0.96f)
        ) {
            Column(Modifier.padding(12.dp)) {
                row.attachments.firstOrNull()?.let { attachment ->
                    Box(
                        Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 290.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOpenImage(attachment.localPath) }
                    ) {
                        FileImage(attachment.localPath, Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 290.dp))
                    }
                    if (message.text.isNotBlank()) Spacer(Modifier.height(10.dp))
                }
                if (message.text.isNotBlank()) {
                    if (isUser) SelectionContainer { Text(message.text, style = MaterialTheme.typography.bodyLarge) }
                    else AssistantTextWithCopy(message.text)
                }
            }
        }
        if (message.status == MessageStatus.ERROR && isUser) {
            Spacer(Modifier.height(5.dp))
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                Row(
                    Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(errorText(message.errorKind), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = onRetry) { Text("Pokušaj ponovo") }
                }
            }
        }
    }
}

@Composable
private fun AssistantTextWithCopy(text: String) {
    val clipboard = LocalClipboardManager.current
    Column {
        MarkdownText(text, Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = { clipboard.setText(AnnotatedString(text)) }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.ContentCopy, "Kopiraj odgovor", modifier = Modifier.size(18.dp))
            }
        }
    }
}

private fun errorText(kind: String?): String = when (kind) {
    AiErrorKind.NO_INTERNET.name -> "Nema internet veze. Proveri vezu i pokušaj ponovo."
    AiErrorKind.RATE_LIMIT.name -> "Trenutno je dostignut limit za AI servis. Pokušaj ponovo malo kasnije."
    AiErrorKind.INVALID_KEY.name -> "AI servis nije pravilno podešen. Proveri API ključ u aplikaciji."
    else -> "Nešto nije uspelo. Pokušaj ponovo."
}

@Composable
private fun ChatComposer(
    draft: String,
    attachmentPath: String?,
    placeholder: String,
    sending: Boolean,
    onDraft: (String) -> Unit,
    onAttach: () -> Unit,
    onRemoveAttachment: () -> Unit,
    onOpenAttachment: () -> Unit,
    onSend: () -> Unit
) {
    Surface(shadowElevation = 6.dp) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (attachmentPath != null) {
                Box(Modifier.width(112.dp).height(78.dp).clip(RoundedCornerShape(10.dp))) {
                    FileImage(
                        path = attachmentPath,
                        modifier = Modifier.fillMaxSize().clickable(onClick = onOpenAttachment),
                        maxDecodeSide = 600
                    )
                    FilledIconButton(
                        onClick = onRemoveAttachment,
                        modifier = Modifier.align(Alignment.TopEnd).size(32.dp)
                    ) { Icon(Icons.Default.Close, "Ukloni fotografiju", modifier = Modifier.size(16.dp)) }
                }
                Spacer(Modifier.height(6.dp))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = onAttach, enabled = !sending, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.AddPhotoAlternate, "Dodaj fotografiju")
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = onDraft,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(placeholder) },
                    enabled = !sending,
                    maxLines = 6
                )
                Spacer(Modifier.width(6.dp))
                FilledIconButton(
                    onClick = onSend,
                    enabled = !sending && (draft.isNotBlank() || attachmentPath != null),
                    modifier = Modifier.size(50.dp)
                ) { Icon(Icons.Default.Send, "Pošalji") }
            }
        }
    }
}
