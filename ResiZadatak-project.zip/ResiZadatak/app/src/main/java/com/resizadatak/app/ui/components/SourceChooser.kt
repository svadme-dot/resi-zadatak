package com.resizadatak.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SourceChooserSheet(
    onDismiss: () -> Unit,
    onGallery: () -> Unit,
    onCamera: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Dodaj fotografiju", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onGallery,
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
            ) {
                Icon(Icons.Default.PhotoLibrary, null)
                Spacer(Modifier.width(10.dp))
                Text("Izaberi iz galerije")
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onCamera,
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
            ) {
                Icon(Icons.Default.PhotoCamera, null)
                Spacer(Modifier.width(10.dp))
                Text("Slikaj zadatak")
            }
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                Text("Otkaži")
            }
        }
    }
}
