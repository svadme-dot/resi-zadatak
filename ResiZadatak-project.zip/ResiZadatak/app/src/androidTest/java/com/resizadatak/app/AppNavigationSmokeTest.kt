package com.resizadatak.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

class AppNavigationSmokeTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun homeShowsPrimaryTaskActionAndSourceChooser() {
        composeRule.onNodeWithText("+ Dodaj novi zadatak").assertIsDisplayed().performClick()
        composeRule.onNodeWithText("Izaberi iz galerije").assertIsDisplayed()
        composeRule.onNodeWithText("Slikaj zadatak").assertIsDisplayed()
    }

    @Test
    fun newChatIsSecondaryAndOpensWithoutPhotoChooser() {
        composeRule.onNodeWithContentDescription("Otvori meni").performClick()
        composeRule.onNodeWithText("Novi chat").assertIsDisplayed().performClick()
        composeRule.onNodeWithText("Kako mogu da pomognem?").assertIsDisplayed()
        composeRule.onNodeWithText("Napiši poruku...").assertIsDisplayed()
    }
}
