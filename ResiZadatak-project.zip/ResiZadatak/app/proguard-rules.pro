# Debug build is the primary target. Add release shrinking rules here later if needed.
