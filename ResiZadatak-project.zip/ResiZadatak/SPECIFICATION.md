Build a complete, functional, native Android application for solving school exercises from photos using the Google Gemini API.

Do not build only a mockup, prototype screen, or UI demo. I want a real Android Studio project with working navigation, local chat history, camera/gallery image input, persistent conversations, real Gemini API integration, and a buildable APK.

Do not ask me unnecessary clarification questions. Make sensible engineering and UI decisions based on the specification below.

# 1. PRIMARY GOAL

The app is a very simple AI assistant for solving school exercises, primarily for:

- primary/elementary school
- optionally secondary/high school
- mathematics
- physics
- chemistry
- similar school subjects

The main user may not be technically skilled, so the UX must be extremely obvious.

The fundamental workflow should feel like:

**Open app → Add new task → choose recent photo or take a photo → optionally type exactly what should be solved → send → receive a clear step-by-step solution in Serbian.**

The app should feel much simpler than a general-purpose AI chatbot.

# 2. LANGUAGE

IMPORTANT:

All user-facing text inside the Android application must be in **Serbian, Latin script**.

Do not use Serbian Cyrillic in the application UI.

Examples:

- "Dodaj novi zadatak"
- "Izaberi iz galerije"
- "Slikaj zadatak"
- "Novi chat"
- "Prethodni razgovori"
- "Napiši šta želiš da rešim..."
- "Pošalji"
- "Rešavam zadatak..."
- "Pokušaj ponovo"

The source code, comments, class names, variable names, README, architecture documentation, etc. may be written in English.

Use correct Serbian Latin characters where appropriate:

č ć š ž đ

# 3. PROVISIONAL APP NAME

Use:

**Reši zadatak**

as the application name.

Make it easy to rename later.

Suggested package name:

`com.resizadatak.app`

If necessary, choose another clean package identifier, but keep the app name "Reši zadatak".

# 4. TECHNOLOGY

Build a native Android app using:

- Kotlin
- Jetpack Compose
- Material 3
- MVVM-style architecture
- Kotlin Coroutines
- StateFlow
- Room for local persistent chat history
- Android Activity Result APIs
- Android Photo Picker for gallery selection
- proper camera capture support
- Google's currently recommended official Gemini / Google Gen AI Android or Java/Kotlin SDK

Before implementing Gemini integration, CHECK THE CURRENT OFFICIAL GOOGLE DOCUMENTATION.

Use only official Google documentation for the Gemini API integration.

Do not guess old SDK names or obsolete API parameters.

Do not use a deprecated Google Generative AI SDK if Google currently recommends a newer Google Gen AI SDK.

Use the latest stable mutually compatible versions of:

- Android Gradle Plugin
- Kotlin
- Compose
- Compose BOM
- Room
- AndroidX libraries
- Google Gen AI SDK

Target the latest stable Android SDK available in the environment.

A reasonable minimum Android version is:

`minSdk 26`

unless there is a strong technical reason to choose another value.

# 5. IMPORTANT GEMINI MODEL REQUIREMENTS

The intended model is:

**Google Gemini 3.7 Flash**

However, model IDs and APIs may change.

Before writing the Gemini integration:

1. Check Google's CURRENT official API documentation.
2. Determine the exact API model identifier corresponding to Gemini 3.7 Flash.
3. Determine the currently supported configuration for the highest reasoning/thinking level.
4. Determine the exact current API configuration for Code Execution.
5. Confirm that image input + high thinking + Code Execution can be used in the required configuration.
6. Use the current official SDK syntax rather than assuming parameter names.

Do NOT invent properties such as `thinkingLevel`, `reasoningLevel`, `thinkingBudget`, or tool configuration unless they exist in the current official API.

If Gemini 3.7 Flash exposes explicit reasoning/thinking levels such as LOW/MEDIUM/HIGH or equivalent:

**use the highest available reasoning/thinking setting.**

Do not rely on an automatic/default thinking setting when an explicit highest setting is available.

Enable:

**Code Execution**

for the model if the official API supports it in this configuration.

The tool should be available to the model so it can use code when useful for:

- calculations
- checking arithmetic
- algebra verification
- equation solving
- numerical validation
- physics calculations
- other appropriate school problems

Do not expose Code Execution logs or irrelevant internal output to the user.

The user should only see the clean educational answer.

Do NOT automatically enable Google Search / web grounding unless it is genuinely required for the implementation.

This app is primarily for self-contained school exercises, so internet search is not normally needed.

Do not disable Google's normal safety mechanisms.

# 6. GEMINI SYSTEM INSTRUCTION

Every conversation with Gemini should receive an internal system/developer instruction conceptually equivalent to the following Serbian instruction.

Use this as the basis:

"Reši zadatak i objasni na srpskom jeziku, latinicom, korak po korak tako da svako može da razume. Prikaži jasan postupak i proveri konačan rezultat.

Ako fotografija sadrži više zadataka, rešavaj samo zadatak, podzadatak ili deo koji je korisnik izričito tražio. Ne rešavaj automatski sve zadatke koji se vide na fotografiji.

Na primer, ako se na fotografiji vide zadaci 350–364, a korisnik napiše 'Reši mi 358. pod a) i b)', rešavaj samo 358. pod a) i b).

Ako fotografija sadrži više zadataka, a korisnik nije naveo koji želi da reši, nemoj nasumično birati niti rešavati sve. Pitaj korisnika koji broj zadatka ili koji deo želi.

Ako se na fotografiji jasno vidi samo jedan zadatak i korisnik nije dodao posebnu tekstualnu instrukciju, možeš rešiti taj zadatak.

Ako neki deo fotografije nije dovoljno čitljiv, nemoj izmišljati tekst. Reci korisniku šta nije čitljivo i zamoli ga da napravi jasniju fotografiju.

Koristi metode i objašnjenja primerene školskom uzrastu. Nemoj nepotrebno koristiti fakultetske ili napredne metode ako se zadatak može rešiti standardnim školskim postupkom.

Ako korisnik traži jednostavnije objašnjenje, objasni jednostavnije.

Ako korisnik traži samo rezultat, možeš odgovoriti kraće.

Ako korisnik pita za određeni prethodni korak, odgovori u kontekstu trenutnog zadatka.

Jasno odvoji postupak od konačnog odgovora.

Proveri račun pre konačnog odgovora kada je to moguće."

The exact wording may be improved, but preserve ALL of these behavioral requirements.

# 7. CRITICAL BEHAVIOR WITH PHOTOS

A photo is NOT automatically an instruction to solve everything visible on the photo.

This is essential.

Example:

A user photographs an entire page from a workbook containing exercises:

350
351
352
...
364

The user then writes:

**"Reši mi 358. pod a) i b)."**

Gemini must receive:

- the image
- the user's text instruction
- the system instruction

and should solve ONLY:

358 a)
358 b)

It must not solve exercises 350–364.

# 8. ONE IMAGE AT A TIME

The main "Add new task" workflow should use:

**one selected image at a time.**

Do not use a multi-select gallery picker in the primary flow.

This is intentional.

The goal is to discourage inexperienced users from selecting 10 different screenshots and sending many unrelated tasks in one request.

One photo may itself contain several exercises on a page.

That is fine.

The user can specify which particular exercise should be solved using the text field.

Later, inside an existing conversation, the user may send another image as a new message if needed, but still limit each individual message to one image.

# 9. APPLICATION START SCREEN

When the app opens, the main screen should be visually simple.

At the top:

- hamburger menu icon on the left
- title "Reši zadatak"

The primary central action should be a large, obvious button/card:

**+ Dodaj novi zadatak**

This must be the most visually prominent action in the app.

Under it, a small explanatory text may say:

**"Izaberi fotografiju zadatka ili ga slikaj kamerom."**

If previous conversations exist, the home screen may optionally show a small "Nedavni zadaci" section below the main button.

However:

Do not let history visually compete with the primary "Dodaj novi zadatak" action.

# 10. "DODAJ NOVI ZADATAK" FLOW

When the user taps:

**Dodaj novi zadatak**

do NOT initially open an empty chat.

Instead immediately display a clean Material 3 bottom sheet or equivalent choice containing:

### Option 1 — primary

**Izaberi iz galerije**

Icon: gallery/photo icon.

This should launch Android's SYSTEM PHOTO PICKER in single-image mode.

The user should naturally see recent photos using Android's native photo picker.

Do not build a custom gallery browser unless absolutely necessary.

The expected real-world workflow is:

1. User photographs a school exercise using the normal phone camera.
2. User opens "Reši zadatak".
3. User taps "Dodaj novi zadatak".
4. User taps "Izaberi iz galerije".
5. Android shows Recent Photos.
6. The photo taken moments ago is near the top.
7. User taps it.

### Option 2

**Slikaj zadatak**

Icon: camera icon.

This should open the phone camera directly.

After successfully taking the photograph:

- return to the app
- attach the photo
- show the task composition screen

### Option 3

A small:

**Otkaži**

action if appropriate.

# 11. AFTER SELECTING OR TAKING A PHOTO

IMPORTANT:

Do NOT automatically submit the image to Gemini immediately.

After a photo is selected, show a new task composition screen.

It should contain:

- a clear image preview
- ability to tap the image to view it larger
- an X/remove icon before sending
- a text input directly under the image

Text field placeholder:

**"Napiši šta želiš da rešim..."**

Under the text box, display a small example:

**Npr. "Reši mi 358. pod a) i b)."**

Then show a clear:

**Pošalji**

button.

The user can therefore:

- send an image with text
- or send an image without text

The Send button should be active as long as at least an image or text exists.

Because this is the "Dodaj novi zadatak" workflow, normally an image will exist.

# 12. IMAGE-ONLY BEHAVIOR

If the user sends only an image:

### Case A:

Exactly one clear exercise is visible.

Gemini may solve it automatically.

### Case B:

Many exercises are visible.

Gemini should NOT solve all of them.

It should answer in Serbian with something similar to:

**"Na slici se vidi više zadataka. Napiši koji zadatak želiš da rešim, na primer: 'Reši 358. pod a) i b)'."**

The exact phrasing may vary naturally.

# 13. AFTER THE FIRST MESSAGE

After the first task is submitted, it becomes a normal chat conversation.

Example visually:

User message:

[photo preview]

"Reši mi 358. pod a) i b)."

Assistant response:

A clear Serbian step-by-step solution.

At the bottom there should be a persistent message composer.

For task-based chats, placeholder:

**"Pitaj nešto o ovom zadatku..."**

Examples of follow-up messages:

- "Ne razumem drugi korak."
- "Zašto si ovde podelio sa 2?"
- "Objasni jednostavnije."
- "Uradi sada i pod v)."
- "Proveri rezultat."
- "Može drugim postupkom?"

Gemini must retain the conversation context.

# 14. IMAGE ATTACHMENT INSIDE AN EXISTING CHAT

Inside an existing conversation, optionally provide a small image/camera attachment button beside the text composer.

Keep it secondary and visually unobtrusive.

It may allow:

- choose one image from gallery
- take one new camera photo

This is useful if the user later wants to send another page or another view of the same exercise.

Still allow only:

**one image per individual message.**

# 15. SIDE NAVIGATION DRAWER

Use a standard mobile navigation drawer opened by the hamburger icon.

The drawer should be simple.

At the top:

Application name:

**Reši zadatak**

Then the PRIMARY action:

**+ Dodaj novi zadatak**

Use a filled/prominent button style.

Immediately below, a SECONDARY action:

**Novi chat**

This must be visually less prominent than "Dodaj novi zadatak".

Then a divider.

Then:

**Prethodni razgovori**

Below that, list the locally stored chat/task history.

Suggested drawer structure:

Reši zadatak

[ + Dodaj novi zadatak ]

Novi chat

---

Prethodni razgovori

Danas

- Reši mi 358. pod a) i b)
- Površina trapeza

Juče

- Brzina i vreme

Ranije

- Razlomci
- Pitagorina teorema

The exact grouping can be adapted if it improves implementation.

# 16. "NOVI CHAT" SECONDARY OPTION

This is separate from "Dodaj novi zadatak".

When the user taps:

**Novi chat**

open a completely blank ordinary text chat.

Do NOT open the gallery.

Do NOT open the camera.

Do NOT require an image.

The initial screen may simply show:

**"Kako mogu da pomognem?"**

with a text field:

**"Napiši poruku..."**

This lets the user ask things like:

- "Objasni mi razlomke."
- "Kako se računa površina kruga?"
- "Šta je ubrzanje?"
- "Daj mi sličan zadatak za vežbu."

This functionality is intentionally secondary.

The app's primary purpose remains photographed exercises.

# 17. CHAT HISTORY

Chat history must survive:

- application restart
- phone restart
- process death

Use Room.

Do NOT keep history only in memory.

Each conversation should store at least:

- unique ID
- conversation type:
  - TASK
  - CHAT
- title
- created timestamp
- updated timestamp

Each message should store:

- unique ID
- conversation ID
- role:
  - USER
  - ASSISTANT
- text
- timestamp
- sending/error state when useful

For image messages, store:

- reference to locally saved image file
- MIME type
- width/height if useful

Do not store huge Base64 strings in Room.

Store images in the application's private/internal file storage and save only the local file path/reference in the database.

When a chat is deleted, remove its stored image files too.

# 18. CONVERSATION TITLES

Do not make a separate Gemini API request just to generate a title unless absolutely necessary.

Avoid wasting API quota.

For v1:

If the first user message contains text, use a shortened version of that text as the title.

Example:

"Reši mi 358. pod a) i b)."

can become:

**"358. zadatak – a) i b)"**

or simply:

**"Reši mi 358. pod a) i b)"**

If the first message is image-only, use something like:

**"Zadatak sa slike"**

optionally with date/time.

Trim very long titles.

Approximately 40–55 characters is enough.

# 19. HISTORY INTERACTIONS

Tapping an item in history should open that conversation.

Provide a small three-dot menu or long-press menu for a conversation with:

**Preimenuj**

**Obriši**

For deletion, show a Serbian confirmation dialog:

**"Obriši razgovor?"**

**"Ovaj razgovor i njegove slike biće trajno obrisani sa uređaja."**

Buttons:

**Otkaži**

**Obriši**

Do not overcomplicate history with folders, tags, accounts, cloud sync, etc.

# 20. LOCAL-FIRST DATA

The app does NOT need:

- accounts
- login
- registration
- cloud synchronization
- social features
- advertisements
- payment screens
- analytics

Keep everything local except the Gemini API requests.

Conversation history and attached images should remain on the device.

# 21. PRIVACY

Do not add analytics or tracking.

Do not upload images anywhere other than what is necessary to make the Gemini API request.

Do not store the user's photos in a remote database.

The locally copied image should live in private app storage.

# 22. PHOTO PICKER

Use Android's modern Photo Picker API.

Single image only.

Prefer an Activity Result Contract such as the currently recommended equivalent of:

`PickVisualMedia`

depending on the current AndroidX API.

Do not ask for broad storage permissions when the system Photo Picker makes them unnecessary.

The picker should naturally show the phone's recent images.

Do NOT attempt to manually reorder the user's image library.

Rely on the Android system UI.

# 23. CAMERA

Implement camera capture robustly.

You may use the recommended Activity Result API for taking a photo and a FileProvider-backed temporary/local URI.

Requirements:

- take one full-resolution image
- return automatically to app after capture
- handle camera cancellation gracefully
- do not leave broken temporary files
- preserve orientation
- show the image preview immediately afterward

Only request camera permission when necessary according to the chosen Android API.

If permission is denied, show a simple Serbian explanation and allow the user to try again.

# 24. IMAGE PROCESSING

School exercise images may contain small printed text.

Do not aggressively downscale images.

Preserve enough resolution for OCR/vision understanding.

Implement reasonable preprocessing before Gemini upload:

- correct EXIF orientation if necessary
- support JPEG
- support PNG
- support WEBP
- gracefully handle HEIC/HEIF selected through Android by decoding/re-encoding if required by the chosen API
- reduce extremely huge camera images to a sensible maximum dimension
- preserve text readability

A reasonable approach for very large photos is a maximum long side around 2048–2560 px with high JPEG quality.

Do not blindly use tiny 512px images.

Do image processing off the main UI thread.

Avoid large-memory Base64 operations if the SDK provides a cleaner byte/stream API.

# 25. GEMINI REQUEST CONSTRUCTION

For the first task message, the request should conceptually contain:

SYSTEM INSTRUCTION

-

IMAGE

-

USER TEXT

For example:

Image:
page containing exercises 350–364

User text:

"Reši mi 358. pod a) i b)."

Gemini therefore receives both the visual information and explicit selection instruction.

For follow-up messages, preserve conversation context.

Do not treat each follow-up as an unrelated single-turn query.

# 26. RESTORING CHAT CONTEXT AFTER APP RESTART

The visible history in Room and the Gemini conversation context must stay logically consistent.

When reopening a previous conversation after the app process was destroyed, reconstruct the relevant chat history from Room before sending the next request.

Include the original task image when required for the model to understand references such as:

"Uradi sada pod v)."

For v1, correctness is more important than sophisticated context compression.

However, avoid needlessly duplicating many unrelated images.

Keep the architecture flexible enough that context-window management could later be improved.

# 27. STREAMING

If the current official Gemini SDK supports reliable streaming responses with the selected model and Code Execution configuration, use streaming.

While the answer is being generated:

Display:

**"Rešavam zadatak..."**

Then progressively render the answer.

If streaming adds incompatibility or instability with Code Execution for the currently supported API, prefer a reliable non-streaming implementation.

Reliability is more important than animation.

# 28. RESPONSE PRESENTATION

AI answers should be visually easy to read.

Support:

- paragraphs
- numbered steps
- bullet lists
- bold text
- basic Markdown
- mathematical expressions as cleanly as reasonably possible

Because this is a school-solving app, good mathematical rendering is valuable.

If there is a stable maintained Compose-compatible Markdown/LaTeX solution compatible with the project's dependency versions, use it.

Support common forms such as:

- fractions
- exponents
- square roots
- equations
- Greek letters
- subscripts

Do not add an enormous fragile dependency solely for perfect LaTeX if it jeopardizes app stability.

Have a graceful plaintext fallback.

Make AI response text selectable where possible.

A small copy icon may be included for assistant messages.

# 29. CHAT UI

Keep the chat UI minimal.

User messages:

- aligned visually as user messages
- attached image preview above or inside the same message card
- text instruction below the image

Assistant messages:

- readable wider cards
- enough spacing for mathematical explanations

Do not add unnecessary avatars, reactions, social-media features, etc.

The focus is readability.

# 30. IMAGE PREVIEW

When a user taps an attached image in chat:

Open a simple full-screen image viewer.

Support:

- pinch to zoom if practical
- pan
- close/back

This is useful for checking what was photographed.

# 31. LOADING STATES

Use Serbian text.

Examples:

During first request:

**"Rešavam zadatak..."**

During normal chat request:

**"Razmišljam..."**

A subtle progress indicator is fine.

Disable duplicate sending while the same message is being submitted.

# 32. ERROR HANDLING

Handle at least:

### No internet

Show:

**"Nema internet veze. Proveri vezu i pokušaj ponovo."**

Button:

**"Pokušaj ponovo"**

### Temporary API/network failure

**"Nešto nije uspelo. Pokušaj ponovo."**

### Rate limit / quota HTTP 429

Use something similar to:

**"Trenutno je dostignut limit za AI servis. Pokušaj ponovo malo kasnije."**

Do not falsely claim a specific reset time unless the API provides one.

### Invalid/expired API key

For development, make this error clear.

### Unreadable image

Normally Gemini should explain that the photo is unclear according to the system instruction.

### User cancels gallery/camera

Simply return to the previous screen.

Do not create a broken empty conversation.

# 33. RETRY

If a request fails:

- retain the user's message
- retain the image
- mark the failed message appropriately
- show "Pokušaj ponovo"

Retry should resend the same intended user request without creating duplicate visible user messages.

# 34. API KEY HANDLING

Do NOT hardcode an API key directly inside committed Kotlin source code.

For the development/personal prototype:

Load:

`GEMINI_API_KEY`

from a non-committed local configuration such as:

`local.properties`

and expose it through BuildConfig or another clean configuration mechanism.

Add the relevant local file to `.gitignore`.

Example concept:

`GEMINI_API_KEY=...`

Do not commit the real key.

IMPORTANT SECURITY NOTE:

An API key embedded into a distributed Android APK can ultimately be extracted.

Therefore structure the networking code behind an abstraction such as:

`AiService`

or:

`GeminiRepository`

so it can later be switched to a small secure backend/proxy without rewriting the UI or database.

For the first personal prototype, direct API access is acceptable if necessary to make the app work quickly, but clearly document that it is not suitable for public distribution.

Do NOT make the non-technical end user manually enter an API key every time the app opens.

# 35. DO NOT ASSUME "FREE FOREVER"

Do not encode any assumption in the UI that Gemini usage is permanently free or unlimited.

The API may have changing quotas and pricing.

The app should simply handle quota responses gracefully.

# 36. DESIGN PRINCIPLES

The app is intended to be easy even for someone who is not comfortable with smartphones.

Therefore:

- large touch targets
- clear Serbian labels
- no hidden essential gestures
- minimum \~48dp tap targets
- no technical AI terminology
- no model selector
- no "temperature"
- no "tokens"
- no "thinking budget"
- no API settings in the normal user UI
- no complex settings page
- no onboarding tutorial unless absolutely necessary

The user should not need to understand what Gemini is.

The app should simply feel like:

**photograph task → get solution**

# 37. VISUAL STYLE

Use a modern but very restrained Material 3 interface.

Prefer:

- clean background
- generous whitespace
- rounded cards
- large central CTA
- one clear primary accent color determined by Material theme
- readable typography
- excellent contrast

Support system:

- Light mode
- Dark mode

Do not create an overly colorful children's design.

It should look modern and trustworthy for both children and adults.

# 38. HOME SCREEN VISUAL HIERARCHY

Approximate conceptual structure:

---

☰ Reši zadatak

```
    [ icon ]

 DODAJ NOVI ZADATAK

```

Izaberi fotografiju zadatka
ili ga slikaj kamerom.

---

Nedavni zadaci

358. zadatak – a) i b)
     Površina trapeza
     Brzina i vreme

---

Do not literally copy ASCII layout.

Create a polished mobile interface based on the hierarchy.

# 39. DRAWER VISUAL HIERARCHY

Approximate structure:

Reši zadatak

[ + Dodaj novi zadatak ]

Novi chat

---

Prethodni razgovori

Danas
358\. zadatak – a) i b)
Površina trapeza

Juče
Brzina i vreme

Ranije
Razlomci

Again, implement this properly using Compose.

# 40. NEW TASK COMPOSER

Approximate visual hierarchy:

Novi zadatak

[ LARGE IMAGE PREVIEW ]

Napiši šta želiš da rešim...

Npr. "Reši mi 358. pod a) i b)."

```
                     [ Pošalji ]

```

Keep it simple and spacious.

# 41. NORMAL TEXT CHAT

When "Novi chat" is selected:

Header:

**Novi chat**

Center empty-state text:

**"Kako mogu da pomognem?"**

Composer:

**"Napiši poruku..."**

Send icon/button.

No photo picker should automatically appear.

# 42. PRIMARY VS SECONDARY ACTIONS

This hierarchy is important:

### Primary:

**Dodaj novi zadatak**

### Secondary:

**Novi chat**

Do not give them equal visual prominence.

The app is not intended to look like a generic ChatGPT clone.

It is a school-task solving app that happens to also include a plain chat mode.

# 43. BACK BUTTON BEHAVIOR

Implement intuitive Android Back behavior.

Examples:

- drawer open → Back closes drawer
- image viewer open → Back closes image viewer
- source-selection bottom sheet open → Back closes it
- photo selected but not sent → Back returns safely
- chat screen → Back returns to home or previous navigation state

Do not accidentally terminate the app from an intermediate modal state.

# 44. STATE RESTORATION

Preserve UI state sensibly during:

- configuration changes
- process recreation where practical

If an API response is currently loading and the process is destroyed, history must remain consistent.

Do not create duplicate user messages after recreation.

# 45. DATABASE MODEL

A reasonable Room structure could be:

`ChatEntity`

- id: String / UUID
- type: TASK or CHAT
- title: String
- createdAt: Long
- updatedAt: Long

`MessageEntity`

- id
- chatId
- role
- text
- timestamp
- status

`AttachmentEntity`

- id
- messageId
- localPath
- mimeType
- width
- height

Use proper foreign keys / cascade behavior where appropriate.

You may adjust the schema if there is a cleaner implementation.

# 46. PROJECT ARCHITECTURE

Keep the project organized but do not over-engineer it.

A suitable structure:

`data/local`

- Room database
- DAO
- entities

`data/remote`

- Gemini client
- request/response handling

`data/repository`

- chat repository
- AI repository

`domain`

- models/use cases only if genuinely useful

`ui/home`
`ui/chat`
`ui/components`
`ui/navigation`
`ui/theme`

Use ViewModels for UI state.

Use Coroutines / StateFlow.

Do not put all application logic into MainActivity.

# 47. DEPENDENCY INJECTION

For this app, use either:

- simple manual dependency injection / application container

or

- Hilt if it clearly improves maintainability without introducing unnecessary complexity.

Do not over-engineer a tiny project purely for architectural purity.

# 48. API ABSTRACTION

Create something conceptually like:

`AiRepository`

with functions such as:

- sendTask(...)
- continueConversation(...)

The Compose UI should NOT directly call Gemini SDK APIs.

This makes it possible to later replace direct Gemini API access with a backend proxy.

# 49. MESSAGE CONTENT MODEL

Internally, a user message may contain:

- text only
- image only
- image + text

Assistant messages contain:

- text

Design the data model accordingly.

# 50. DO NOT AUTO-SOLVE ON IMAGE SELECTION

This requirement is important enough to repeat:

Selecting an image must NOT immediately call Gemini.

Sequence:

1. select/take image
2. preview image
3. allow user to type what they want
4. user taps Send
5. call Gemini

# 51. EXAMPLE REAL USER FLOW

User photographs one workbook page containing exercises 350–364.

User opens app.

Taps:

**Dodaj novi zadatak**

Taps:

**Izaberi iz galerije**

Selects the newest photo.

App displays the photo.

User writes:

**"Reši mi 358. pod a) i b)."**

User taps:

**Pošalji**

The request sent to Gemini contains:

- system instruction
- selected image
- user's text

Gemini uses high reasoning and Code Execution when useful.

App displays only the solution to 358 a) and b).

User then writes:

**"Ne razumem kako si dobio rezultat pod b)."**

Gemini answers using the existing context.

This complete workflow must work.

# 52. EXAMPLE SECONDARY FLOW

User opens drawer.

Taps:

**Novi chat**

No gallery appears.

Blank chat opens.

User writes:

**"Objasni mi Pitagorinu teoremu kao za 7. razred."**

Gemini answers in Serbian Latin.

Conversation is saved to history exactly like task conversations.

# 53. API RESPONSE QUALITY

Do not instruct Gemini to be unnecessarily verbose every time.

It should be detailed enough for a pupil to understand but still clear.

Prefer formatting similar to:

**Zadatak 358. a)**

1. ...
2. ...
3. ...

**Rezultat: ...**

Then:

**Zadatak 358. b)**

...

**Rezultat: ...**

For mathematics, use proper notation where possible.

For physics, clearly distinguish:

- dato
- formula
- račun
- rezultat
- units

when that structure is appropriate.

For geometry:

- identify known values
- select formula/theorem
- substitute
- calculate
- state final answer

But let Gemini adapt to the type of problem rather than forcing one exact template for everything.

# 54. SCHOOL-LEVEL METHODS

The assistant should prefer methods appropriate for the likely school level.

For example:

Do not solve an elementary-school geometry problem using advanced calculus merely because it is possible.

Do not unnecessarily introduce matrices, complex numbers, derivatives, etc. unless the exercise genuinely requires them.

If multiple standard methods exist, choose the most understandable school method.

# 55. HANDWRITTEN INPUT

The app should support photographed handwritten exercises.

Do not implement a separate OCR pipeline unless it proves necessary.

Gemini's multimodal understanding should receive the original image.

If the writing is too unclear, the assistant should say so instead of hallucinating.

# 56. NO AUTOMATIC BATCH SOLVING

Never add a feature like:

"Solve all tasks on page"

as the default.

The entire UX should encourage:

**one requested task at a time.**

This keeps responses focused and reduces unnecessary API usage.

# 57. ACCESSIBILITY

Use:

- content descriptions for important icons
- sufficient contrast
- scalable text
- reasonably large controls
- clear focus behavior

Avoid relying on icon meaning alone for the primary actions.

For example use:

camera icon + "Slikaj zadatak"

rather than just a camera icon.

# 58. NO UNNECESSARY SETTINGS

Do NOT initially add:

- model selection
- reasoning level selection
- token limits
- temperature slider
- theme customization menu
- prompt editor
- API log viewer

Those belong to developer configuration, not normal user UX.

# 59. OPTIONAL SMALL FEATURES THAT ARE ACCEPTABLE

Only if they do not significantly complicate the app:

- copy assistant response
- tap image to enlarge
- retry failed response
- rename chat
- delete chat
- automatic scroll to newest message
- small "scroll to bottom" button if user scrolls far upward

Do not allow these extras to delay or destabilize the core app.

# 60. WHAT NOT TO BUILD

Do not build:

- website
- React web app
- Flutter app unless native Android is impossible
- iOS app
- desktop app
- generic ChatGPT clone
- Firebase account system
- social features
- subscription system
- ads
- unnecessary cloud database
- multi-user backend

The target is a native Android application.

# 61. BUILD QUALITY

The final project should:

- compile
- install
- launch
- have no obvious crashes
- correctly open Photo Picker
- correctly launch camera
- persist chats
- restore chats
- call the real Gemini API
- show API responses
- handle errors
- build a debug APK

Do not leave critical functionality as TODO placeholders.

# 62. TEST THE FOLLOWING MANUALLY OR AUTOMATICALLY

At minimum verify:

### Test 1

Fresh install → home appears → "Dodaj novi zadatak" visible.

### Test 2

Tap "Dodaj novi zadatak" → source chooser appears.

### Test 3

Gallery → system Photo Picker opens → select one image → preview appears.

### Test 4

Camera → take photo → return → preview appears.

### Test 5

Photo does NOT auto-send before pressing "Pošalji".

### Test 6

Image + Serbian instruction sends successfully.

### Test 7

Gemini response is displayed.

### Test 8

Follow-up text continues same conversation.

### Test 9

Close and reopen app → conversation still exists.

### Test 10

Open drawer → history visible.

### Test 11

Tap previous conversation → messages and image restore correctly.

### Test 12

"Nov chat" opens without gallery/camera.

### Test 13

A text-only Gemini conversation works.

### Test 14

No-internet error does not crash app.

### Test 15

Failed request can be retried.

### Test 16

Delete chat removes it and its locally stored images.

# 63. BUILD THE PROJECT, DO NOT JUST EXPLAIN IT

If your environment supports file creation and command execution:

1. Create the full Android Studio project.
2. Create all Kotlin source files.
3. Create Gradle configuration.
4. Create Manifest.
5. Create icons/resources needed.
6. Implement Room.
7. Implement Compose UI.
8. Implement navigation.
9. Implement gallery.
10. Implement camera.
11. Implement image storage.
12. Implement Gemini integration.
13. Implement chat persistence.
14. Run the Gradle build.
15. Fix compile errors.
16. Repeat until `assembleDebug` succeeds.
17. Produce the debug APK.
18. Also provide the complete project as a ZIP if possible.

Do not stop after generating source code without attempting to build it if Android build tooling is available.

# 64. IF ANDROID BUILD TOOLS ARE NOT AVAILABLE

Still create a complete project structure.

Do not replace it with pseudocode.

Clearly state what could not be locally compiled because of environment limitations.

The project should be ready to open in Android Studio.

# 65. README

Create a concise README explaining:

- what the app does
- requirements
- where to put `GEMINI_API_KEY`
- how to build
- how to run
- which Gemini model ID is currently configured
- which thinking/reasoning configuration is used
- how Code Execution is enabled
- any API limitations discovered from official Google docs
- security warning about embedding an API key in an APK
- where the final APK is located

# 66. GOOGLE API VERIFICATION

Because Gemini APIs evolve quickly, before finalizing the Gemini client, explicitly verify from CURRENT OFFICIAL GOOGLE SOURCES:

- exact Gemini 3.7 Flash model ID
- whether it is stable, preview, or otherwise
- correct image input method
- correct system instruction syntax
- highest reasoning/thinking configuration
- Code Execution tool syntax
- chat/multi-turn syntax
- streaming compatibility
- current official SDK dependency

Do not rely on old examples from memory.

If the exact marketing name "Gemini 3.7 Flash" does not correspond directly to an API model ID, identify the correct current official model ID.

Keep that ID in one centralized configuration constant so it can easily be changed later.

Do not silently downgrade to a weaker model without documenting it.

# 67. FINAL PRIORITY ORDER

When engineering decisions conflict, prioritize in this order:

1. App actually works.
2. "Dodaj novi zadatak" workflow is extremely simple.
3. Gemini gets image + exact user instruction.
4. Multiple exercises on one image are NOT all solved automatically.
5. Conversation history persists.
6. Follow-up chat retains context.
7. All visible UI is Serbian Latin.
8. Highest supported Gemini reasoning is enabled.
9. Code Execution is enabled when officially supported.
10. UI looks clean and modern.
11. Additional optional features.

# 68. FINAL EXPECTED RESULT

I should end up with an Android application where a non-technical person can do this:

1. Photograph a page from a workbook.
2. Open "Reši zadatak".
3. Tap "Dodaj novi zadatak".
4. Tap "Izaberi iz galerije".
5. Tap the newest photo.
6. Type:
   "Reši mi 358. pod a) i b)."
7. Tap "Pošalji".
8. Receive a clear Serbian Latin step-by-step solution.
9. Ask:
   "Objasni mi drugi korak."
10. Receive a contextual explanation.
11. Later reopen the same conversation from history.

And alternatively:

1. Open the side menu.
2. Tap the secondary "Novi chat".
3. Ask a text-only school question without adding a photo.

Implement this full application now.