# Manual test checklist

These are the acceptance checks from the requested v1 flow. They require a real Android device/emulator and a successful Gradle build, so they could not be executed in the generation sandbox.

- [ ] Fresh install opens Home and prominently shows **Dodaj novi zadatak**.
- [ ] Tapping **Dodaj novi zadatak** opens the source chooser.
- [ ] **Izaberi iz galerije** opens Android's system single-image Photo Picker.
- [ ] Selecting one image returns to the app and shows the preview.
- [ ] **Slikaj zadatak** opens the camera and a successful capture returns to the preview.
- [ ] Selecting/capturing a photo does **not** call Gemini before **Pošalji**.
- [ ] Image + Serbian instruction sends successfully.
- [ ] Gemini response appears in Serbian Latin.
- [ ] Follow-up message continues the same conversation context.
- [ ] App restart preserves the conversation and image.
- [ ] Drawer shows previous conversations.
- [ ] Opening a previous conversation restores its messages/image.
- [ ] **Novi chat** opens without automatically opening gallery/camera.
- [ ] Text-only Gemini chat works.
- [ ] No-internet state shows an error without crashing.
- [ ] Failed user request can be retried without a duplicate user bubble.
- [ ] Deleting a conversation removes it and its private stored image files.
- [ ] Photo containing many exercises + instruction for only one subtask produces only that requested solution.
- [ ] Photo containing many exercises with no specific task instruction asks which task to solve instead of solving all.
